from setuptools import setup, find_packages
from RobloxPyApi3.Version import __Copyright__
Version = "1.2.0"

Description = "RobloxPyApi3 is a great Roblox API wrapper that offers a variety of features. With the latest update, you can create Roblox games in Python and communicate with Roblox Studio. Additionally, RobloxPyApi3 can now use API endpoints that require Captcha, such as sign up, login, and following users. However, please note that these features are in beta and may be subject to breaking changes. All of the features of RobloxPyApi3 are copyrighted, so please do not steal any code or use any features without permission, including the Place creation XML method. More Roblox endpoints are coming soon! Thanks for using RobloxPyApi3!!"

Long_Description = f"""

A Roblox Api wrapper allowing to make automated bots with Python3.
This package doesnt made to perform DDoS attacks or any illegal actions.
This package made for controlling a profile, or basically, controlling a BOT.
I hope this package is useful and all my hard work is worth it.
------------------- IMPORTANT THING: -------------------------------
Function: 'RobloxPyApi3.Get_Robux_Count()' is a function that gets THE AMOUNT OF ROBUX in your account.
Some people will think it actually a way to GET FREE ROBUX but its not.
--------------------------------------------------------------------
QNA:
Q: Why functions always use cookie ?
A: This package needs to use roblox API with your cookie, the cookie helps the function to authorize the user.
Q: Does that module beams Roblox account and steals the cookie?
A: No, we dont use discord API (Discord Webhook) to perform process. We dont use discord.py or any discord links except for those
Discord links that direct to my Discord server where you can report bugs or contact me.
Q: Where can I contact the owner or report bugs ?
A: You can report any issues in my Github or in upcoming Discord server.
Q: Is this package easy to use ?
A: Yes, it is. if its hard for you to use this package,
you can simply use client = RobloxPyApi3.Client(".ROBLOSECURITY cookie here",True) print(client.Get_Robux())
or you can use bot = RobloxPyApi3.bot(".ROBLOSECURITY cookie here",True) print(bot.Get_Robux()). So this is not hard.
Q: Are RobloxPyApi3.bot and RobloxPyApi3.Client exact same things ?
A: Yes they are the same, people will easily understand the classes.
Q: Why can't you use multiple cookies ?
A: You can't use multiple cookies because Roblox did a Patch on multiple cookies due to
scam bots and trump bots accident in Roblox.
---------  Usage Number 1:  ------------
 import RobloxPyApi3
 client = RobloxPyApi3.Client("ROBLOSECURITY cookie goes here",showErrors=True) # or False     showErrors Used to debug code for errors, if you dont want program to show errors, set showErrors to False.
 Robux = client.Get_Robux()
 print(Robux,client.Robux)
 ---------  Usage Number 2:  ------------
 import RobloxPyApi3
 bot = RobloxPyApi3.bot("ROBLOSECURITY cookie goes here",showErrors=True)
 Robux = bot.Get_Robux()
 print(Robux,bot.Robux)
 ---------  Usage Number 3:  ------------
 import RobloxPyApi3
 robux = RobloxPyApi.Get_Robux("ROBLOSECURITY Cookie goes here",showErrors=False)
 print(robux)
---------  Output/Run/Results: ---------
        Your robux amount
----------------------------------------
See __Changes__ for changes. 
Requirements:
     Roblox Bot account
    .ROBLOSECURITY cookie for account authorization.
     Internet access
---- CHANGES IN {Version} Date: // ----:
1.0.5 is the Release Version.
1. Added friends Api.
2. fixed bugs.
3. Added friends api inside the bot class.
4. Added friends api inside the Client class.
5. Added friends api inside the main python script.
-----------------------------------------
{__Copyright__}
-----------------------------------------
Thanks for using this Package.
"""
setup(
    name="RobloxPyApi3",
    version=Version,
    author="pyProjects3 (github.com/pyProjects3)",
    description=Description,
    long_description_content_type="text/markdown",
    long_description=Long_Description,
    packages=find_packages(),
    license="MIT",

    package_data= {'Place':["*.py"]},
    include_package_data=True,
    install_requires=['requests','colorama','psutil','RobloxPyApi3Update'],
    keywords=["Roblox","Api",'wrapper',"Bot",'Client','Automated',"Account Management","rbx","Python3","Place automation","post requests","get requests","JSON","Authorization","Roblox Development"],
    classifiers=[
        "Development Status :: 1 - Planning",
        "Intended Audience :: Developers",
        "Programming Language :: Python :: 3",
        "Operating System :: Microsoft :: Windows",
    ]
)
