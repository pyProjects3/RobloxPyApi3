
__Author__ = "pyProjects3"
__Copyright__ = """
Copyright © 2023 Python3 Projects Development 
All rights reserved. This software and its associated documentation files (the "Software") are the exclusive property of Python3 Projects Development and may not be reproduced, copied, modified, distributed, transmitted, displayed, or otherwise exploited in any manner without the express written consent of Python3 Projects Development.
Unauthorized copying, distribution or use of this Software, or any portion thereof, may result in severe civil and criminal penalties, and will be prosecuted to the maximum extent possible under the law.
This Software is provided "AS IS" without warranty of any kind, either express or implied, including, but not limited to, the implied warranties of merchantability or fitness for a particular purpose.
By using this Software, you agree to abide by these terms and conditions, and acknowledge that any unauthorized use may cause irreparable harm to Python3 Projects Development  and its reputation.
"""
__PythonVersion__ = "Python 3.8"
__ProgrammingLanguage__ = "Python"
__FileName__ = "Version.py"
__Package__ = "RobloxPyApi3"
__GitHubUsername__ = "pyProjects3"
__GitHubPage__ = None
__Discord__ = "Coming soon..."
__DiscordServer__ = "Coming soon..."
__GitHub__ = "https://github.com/pyProjects3"
__moduleName__ = "RobloxPyApi3"
__RobloxUserName__ = "immahack2677"
__RobloxProfile__ = "https://roblox.com/users/2013402955/profile"
__RobloxUserId__ = "2013402955"
__PackageVersion__ = "1.0.6"
