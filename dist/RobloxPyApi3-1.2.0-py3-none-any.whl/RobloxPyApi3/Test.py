import subprocess
subprocess.Popen("notepad.exe")